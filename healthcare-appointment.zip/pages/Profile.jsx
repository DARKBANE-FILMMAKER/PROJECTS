import React from "react";
import ProfileCard from "../components/ProfileCard";

export default function Profile() {
  const user = {
    name: "John Doe",
    email: "john@example.com",
    role: "Patient"
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Profile</h1>
      <ProfileCard user={user} />
    </div>
  );
}