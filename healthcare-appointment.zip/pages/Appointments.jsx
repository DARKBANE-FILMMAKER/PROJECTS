import React from "react";
import CalendarView from "../components/CalendarView";

export default function Appointments() {
  const events = [
    { title: "Checkup with Dr. Smith", date: "2025-07-20" },
    { title: "Dental Cleaning", date: "2025-07-22" }
  ];

  const handleDateClick = (info) => {
    alert("Date clicked: " + info.dateStr);
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Appointments</h1>
      <CalendarView events={events} handleDateClick={handleDateClick} />
    </div>
  );
}