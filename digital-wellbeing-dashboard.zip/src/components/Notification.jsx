import React from "react";

export default function Notification() {
  return (
    <div className="bg-green-100 p-4 rounded-xl shadow-md">
      <h2 className="text-lg font-semibold mb-2">Daily Reminder</h2>
      <p>Take a 5-minute break every hour to rest your eyes 👀✨</p>
    </div>
  );
}
