import React from "react";
import Chart from "./components/Chart";
import Notification from "./components/Notification";

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <Chart />
      <Notification />
    </div>
  );
}
